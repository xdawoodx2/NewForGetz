
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

public class IndexModel : PageModel
{
    private readonly AppDbContext _db;

    public IndexModel(AppDbContext db)
    {
        _db = db;
    }

    [BindProperty]
    public string MessageText { get; set; }

    public List<MessageItem> Messages { get; set; }

    public void OnGet()
    {
        Messages = _db.TestTable.ToList();
    }

    public IActionResult OnPost()
    {
        if (!string.IsNullOrWhiteSpace(MessageText))
        {
            _db.TestTable.Add(new MessageItem { Message = MessageText });
            _db.SaveChanges();
        }

        return RedirectToPage();
    }
}
